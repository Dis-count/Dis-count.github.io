#一点点说明

这是[BeiYuu.com](http://beiyuu.com)的示例代码，如果你看了[使用Github Pages建独立博客](http://beiyuu.com/github-pages)，希望看下去哦：

* 马上动手，很赞
* 感谢认可
* 推荐阅读：[我为什么写博客？](http://beiyuu.com/why-blog)
* 想复用我的设计，没问题，标个出处就好啦
* 转载也没问题，标个出处呗少年
* 恩，认真的童鞋最可爱啦~
